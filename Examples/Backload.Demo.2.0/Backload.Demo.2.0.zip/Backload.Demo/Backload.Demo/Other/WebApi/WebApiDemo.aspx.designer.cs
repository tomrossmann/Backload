//------------------------------------------------------------------------------
// <automatisch generiert>
//     Der Code wurde von einem Tool generiert.
//
//     �nderungen an der Datei f�hren m�glicherweise zu falschem Verhalten, und sie gehen verloren, wenn
//     der Code erneut generiert wird. 
// </automatisch generiert>
//------------------------------------------------------------------------------

namespace Backload.Demo.WebApi {
    
    
    public partial class WebApiDemo {
    }
}
