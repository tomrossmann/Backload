using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Backload.Demo.Controllers
{
    using System.IO;

    public class HomeController : Controller
    {

        // Start view
        public ActionResult Index()
        {
            return View();
        }

    }
}
