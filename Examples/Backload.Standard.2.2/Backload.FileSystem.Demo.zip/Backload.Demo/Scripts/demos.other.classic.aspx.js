
/* global $, window */

$(function () {
    'use strict';

    // Name of a web application (usually in full IIS mode). Can be found in Properties/Web/Server/Project-Url. Example: http://localhost/Demo (Name of web application is "Demo")
    var web_app = '/';

    // In this example we use a custom Generic Handler
    // In this example we set an objectContect (id) in the URL query (or as form parameter). The value of the opjectContext parameter   
    // will be added to the path as a sub-folder of the storage root folder (storageRoot\objectContext\file). You can assign a user id
    // to objectContext as user directory. Instead of setting the objectContext client side you can also be set server side, 
    // e.g. server side events (see also Custom Data Provider Demo, 2.2+).
    var url = web_app + 'Other/Handler/FileHandler.ashx?objectContext=C5F260DD3787';


    // Initialize the jQuery File Upload widget:
    $('#fileupload').fileupload({
        url: url,
        acceptFileTypes: /(jpg)|(jpeg)|(png)|(gif)|(pdf)$/i              // Allowed file types
    })


    // Load existing files:
    $('#fileupload').addClass('fileupload-processing');
    $.ajax({
        // Uncomment the following to send cross-domain cookies:
        // xhrFields: {withCredentials: true},
        url: url,
        dataType: 'json',
        context: $('#fileupload')[0]
    }).always(function () {
        $(this).removeClass('fileupload-processing');
    }).done(function (result) {
        $(this).fileupload('option', 'done')
            .call(this, $.Event('done'), { result: result });
    });
});
