This archive contains supporting files for the Backload component
for new ASP.NET projects (using project.json). Copy the content of 
this archive to your project. 


Note:
If you have different folder for client side web files than the 
default "wwwroot" folder, you need to copy the content of the 
wwwroot folder to your client side web files folder.