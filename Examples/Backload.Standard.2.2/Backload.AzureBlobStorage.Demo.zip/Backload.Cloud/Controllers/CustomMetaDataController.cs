using Backload.Contracts.Context;
using Backload.Contracts.FileHandler;
using Backload.Contracts.Status;
using Backload.Helper;
using Newtonsoft.Json;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Helpers;
using System;
using System.Collections.Generic;


namespace Backload.Cloud.Controllers
{

    /// <summary>
    /// Custom controller for the events demo  Note: events must be enabled in the config.
    /// </summary>
    public class CustomMetaDataController : Controller
    {
        /// <summary>
        /// A custom file handler. 
        /// To access it in an Javascript ajax request use: <code>var url = "/CustomEvents/FileHandler/";</code>.
        /// </summary>
        [AcceptVerbs(HttpVerbs.Get|HttpVerbs.Post|HttpVerbs.Put|HttpVerbs.Delete|HttpVerbs.Options)]
        public async Task<ActionResult> FileHandler()
        {
            try
            {
                // Create and initialize the handler
                IFileHandler handler = Backload.FileHandler.Create();


                // Attach event handlers to events
                handler.Events.StoreFileRequestStarted += Events_StoreFileRequestStarted;


                // Init Backloads execution environment and execute the request
                handler.Init(HttpContext.Request);
                IBackloadResult result = await handler.Execute();


                // Helper to create an ActionResult object from the IBackloadResult instance
                return ResultCreator.Create(result);
            }
            catch
            {
                return new HttpStatusCodeResult(HttpStatusCode.InternalServerError);
            }
        }

        /// <summary>
        /// In this demo, we extend the metadata sent by the client and add internal metadata to the file
        /// </summary>
        void Events_StoreFileRequestStarted(IFileHandler sender, Contracts.Eventing.IStoreFileRequestEventArgs e)
        {
            var file = e.Param.FileStatusItem;

            // This demo adds internal and public meta data to the file to store.
            // Public meta data will be posted back to the client and can be used on the website like in this demo.
            // Internal meta data will not be posted back to the client, and is intended for internal use only.
            if (file.MetaData.PublicMetaData != null)
            {
                // Public metadata will be posted back to the client.
                // PublicMetaData is of type object. You can assign a Json string (JsonConvert.SerializeObject()) or any other type. 
                // If it is not a Json string, it will be serialized internally.
                var pubMeta = (PublicMeta)JsonConvert.DeserializeObject(file.MetaData.PublicMetaData.ToString(), typeof (PublicMeta));
                int random = new Random().Next(0, 19);
                pubMeta.ReviewedBy = _randomNames[random];
                pubMeta.Rating = new Random().Next(1, 5);
                file.MetaData.PublicMetaData = pubMeta;

                // Private metadata will not be posted back to the client.
                // PrivateMetaData is of type object. You can assign a Json string (JsonConvert.SerializeObject()) or any other type. 
                // If it is not a Json string like here, it will be serialized internally.
                var privMeta = new InternalMeta(true, 2, "Valuable object. Handle carefully.", "A3/214");
                file.MetaData.PrivateMetaData = privMeta;
            }
        }


        /// Demo class used to add public meta data to the file. Public meta data will be posted back to the client, 
        /// in a GET or POST request and can be displayed or used on the website
        public class PublicMeta
        {
            public PublicMeta()
            { }

            public string  Author { get; set; }
            public long Created { get; set; }
            public string ReviewedBy { get; set; }
            public int Rating { get; set; }
        }
        
        /// <summary>
        /// Demo class used to add internal meta data to the file. Internal meta data will not be posted back to the client, and
        /// is intended for internal use only
        /// </summary>
        public class InternalMeta
        {
            public InternalMeta(bool processed, int condition, string remarks, string store)
            {
                this.Processed = processed;
                this.Condition = condition;
                this.Remarks = remarks;
                this.Store = store;
            }

            public bool Processed { get; set; }
            public int Condition { get; set; }
            public string Remarks { get; set; }
            public string Store { get; set; }
        }

        // Some random names for the demo
        private string[] _randomNames = new string[] { "Annita Luhman", "Yelena Hugh", "Eugena Delosh", "Arielle Lorentz", "Rupert Ezzell", "Rosena Venable", "Velma Blatt", "Larae Trace", "Angelique Reichel", "Lavonia Braverman", "Yuko Loggins", "Tari Guidotti", "Myriam Fogarty", "Fredric Tsan", "Salvatore Harps", "Coralee Dressler", "Nathan Null", "Tula Corkill", "Gretta Rough", "Dannie Fennell" };
    }
}
