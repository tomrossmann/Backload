using Backload.Contracts.Context;
using Backload.Contracts.FileHandler;
using Backload.Contracts.Status;
using Backload.Helper;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace Backload.Cloud.Controllers
{

    /// <summary>
    /// Custom controller for the events demo  Note: events must be enabled in the config.
    /// </summary>
    public class CustomEventsController : Controller
    {
        // User id. In a real project this user id should be a real logged in user id
        private string _currentLoggedInUserId = string.Empty;

        /// <summary>
        /// A custom file handler. 
        /// To access it in an JavaScript AJAX request use: <code>var url = "/CustomEvents/FileHandler/";</code>.
        /// </summary>
        [AcceptVerbs(HttpVerbs.Get | HttpVerbs.Post | HttpVerbs.Put | HttpVerbs.Delete | HttpVerbs.Options)]
        public async Task<ActionResult> FileHandler()
        {
            // Fake user id for demo purposes
            _currentLoggedInUserId = "97966ABE-0691-4874-958C-98AD07BB461C";

            try
            {
                // Create and initialize the handler
                IFileHandler handler = Backload.FileHandler.Create();


                // Attach event handlers to events
                handler.Events.ConfigurationLoaded += Events_ConfigurationLoaded;
                handler.Events.GetFilesRequestStarted += Events_GetFilesRequestStarted;
                handler.Events.GetFilesRequestFinished += Events_GetFilesRequestFinished;
                handler.Events.StoreFileRequestStarted += Events_StoreFileRequestStarted;


                // Init the execution environment and execute the request
                handler.Init(HttpContext.Request);
                IBackloadResult result = await handler.Execute();


                // Helper to create an ActionResult object from the IBackloadResult instance
                return ResultCreator.Create(result);
            }
            catch
            {
                return new HttpStatusCodeResult(HttpStatusCode.InternalServerError);
            }
        }


        void Events_ConfigurationLoaded(IFileHandler sender, Contracts.Eventing.IConfigurationLoadedEventArgs e)
        {
            var config = e.Param.Configuration;

            // We can use the server side only ObjectsRoot attribute, to store file in a users private virtual folder
            // Unlike ObjectsContext, which is a client side parameter and will be exchanged with the client, 
            // ObjectsRoot is server side only and will not posted back to or accepted from the client
            config.Storage.CloudConfig.AzureBlobStorage.ObjectsRoot = _currentLoggedInUserId;
        }



        void Events_GetFilesRequestStarted(IFileHandler sender, Backload.Contracts.Eventing.IGetFilesRequestEventArgs e)
        {
            // Backload component has started the internal GET handler method. 
            string searchPath = e.Param.SearchPath;
        }


        void Events_GetFilesRequestFinished(IFileHandler sender, Backload.Contracts.Eventing.IGetFilesRequestEventArgs e)
        {
            // Backload component has finished the internal GET handler method. 
            // Results can be found in e.Param.FileStatus or sender.FileStatus

            IFileStatus status = e.Param.FileStatus;
        }



        void Events_StoreFileRequestStarted(IFileHandler sender, Contracts.Eventing.IStoreFileRequestEventArgs e)
        {
            //e.Context.Configuration.Images.ForceImageType = "image/png";
            //if (e.Param.FileStatusItem.MainContentType == "image")
            //    e.Param.FileStatusItem.ContentType = "image/png";
            //var storageInfo = e.Param.FileStatusItem.StorageInfo;
        }
    }
}
