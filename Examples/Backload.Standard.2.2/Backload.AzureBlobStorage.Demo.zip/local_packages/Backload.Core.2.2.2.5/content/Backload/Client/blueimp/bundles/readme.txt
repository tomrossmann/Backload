This folder contains jQuery File Upload Plugin theme based bundles 
that can be used with the corresponding ui themes. 

Note: All themes share the same style bundle: jquenry.fileupload.bundle.min.css