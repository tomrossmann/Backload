﻿using Backload.Controllers;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Backload;
using System.Threading.Tasks;
using Backload.Plugin.Handler;
using System.Threading;
using System.Diagnostics;

namespace Backload.Issues.Issue17.Test02.Controllers
{
    public class FileUploadController : Controller
    {
        public ActionResult FileHandler()
        {
            try
            {
                FileUploadHandler handler = new FileUploadHandler(Request, this);
                handler.IncomingRequestStarted += handler_IncomingRequestStarted;
                handler.StoreFileRequestException += handler_StoreFileRequestException;
                handler.ProcessPipelineExceptionOccured += handler_ProcessPipelineExceptionOccured;

                ActionResult result = handler.HandleRequest();
                return result;
            }
            catch (Exception e)
            {
            }

            return null;
        }

        public void handler_IncomingRequestStarted(object sender, Eventing.Args.IncomingRequestEventArgs e)
        {
        }

        void handler_StoreFileRequestException(object sender, Eventing.Args.StoreFileRequestEventArgs e)
        {
            Exception exception = e.Param.FileStatusItem.Exception;
            if (e.Context.TraceManager.Enabled) e.Context.TraceManager.TraceSource.TraceEvent(TraceEventType.Error, 90000001, exception.Message);
        }

        void handler_ProcessPipelineExceptionOccured(object sender, Eventing.Args.ProcessPipelineExceptionEventArgs e)
        {
            Exception exception = e.Param.Exception;
            if (e.Context.TraceManager.Enabled) e.Context.TraceManager.TraceSource.TraceEvent(TraceEventType.Error, 90000002, exception.Message);
        }



    }
}
