using Backload.Contracts.Context;
using Backload.Contracts.FileHandler;
using Backload.Contracts.Status;
using Backload.Helper;
using Microsoft.AspNet.Hosting;
using Microsoft.AspNet.Mvc;
using Microsoft.Extensions.PlatformAbstractions;
using System;
using System.Net;
using System.Threading.Tasks;

namespace Backload.Demo.Controllers
{

    /// <summary>
    /// Custom controller for the events demo  Note: events must be enabled in the config.
    /// </summary>
    public class CustomEventsController : Controller
    {
        private IHostingEnvironment _hosting;
        private IApplicationEnvironment _application;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="application">IApplicationEnvironment instance (injected)</param>
        /// <param name="hosting">IHostingEnvironment instance (injected)</param>
        public CustomEventsController(IApplicationEnvironment application, IHostingEnvironment hosting)
        {
            _application = application;
            _hosting = hosting;
        }

        
        /// <summary>
        /// A custom file handler. 
        /// To access it in an Javascript ajax request use: <code>var url = "/CustomEvents/FileHandler/";</code>.
        /// </summary>
        public async Task<ActionResult> FileHandler()
        {
            try
            {
                // Create and initialize the handler
                IFileHandler handler = Backload.FileHandler.Create();


                // Attach event handlers to 
                handler.Events.ConfigurationLoaded += Events_ConfigurationLoaded;
                handler.Events.IncomingRequestStarted += Events_IncomingRequestStarted;
                handler.Events.GetFilesRequestStarted += Events_GetFilesRequestStarted;
                handler.Events.GetFilesRequestFinished += Events_GetFilesRequestFinished;
                handler.Events.StoreFileRequestStarted += Events_StoreFileRequestStarted;
                handler.Events.StoreFileRequestFinished += Events_StoreFileRequestFinished;


                // Init Backloads execution environment and execute the request
                handler.Init(this.HttpContext, _application, _hosting);
                IBackloadResult result = await handler.Execute();


                // Helper to create an ActionResult object from the IBackloadResult instance
                return ResultCreator.Create(result);
            }
            catch (Exception e)
            {
                int i = e.Message.Length;
                return new HttpStatusCodeResult((int)HttpStatusCode.InternalServerError);
            }
        }



        /// <summary>
        /// Configuration loaded. This is the first event fired.
        /// </summary>
        private void Events_ConfigurationLoaded(IFileHandler sender, Contracts.Eventing.IConfigurationLoadedEventArgs e)
        {
            // You can change configuration values here
            var config = e.Param.Configuration;

            // Set a user id server side to store files in a user related folder
            // You can also use e.Param.BackloadValues.ObjectContext = "97966ABE-0691-4874-958C-98AD07BB461C";
            config.Storage.FileSystem.ObjectsRoot = "97966ABE-0691-4874-958C-98AD07BB461C";

        }



        void Events_IncomingRequestStarted(IFileHandler sender, Backload.Contracts.Eventing.IIncomingRequestEventArgs e)
        {
            // Execution context initialized.
            // Use this event to change storage root path or urls
            var root = sender.BasicStorageInfo;
        }


        void Events_GetFilesRequestStarted(IFileHandler sender, Backload.Contracts.Eventing.IGetFilesRequestEventArgs e)
        {
            // Backload component has started the internal GET handler method. 
            string searchPath = e.Param.SearchPath;
        }



        void Events_GetFilesRequestFinished(IFileHandler sender, Backload.Contracts.Eventing.IGetFilesRequestEventArgs e)
        {
            // Backload component has finished the internal GET handler method. 
            // Results can be found in e.Param.FileStatus or sender.FileStatus

            IFileStatus status = e.Param.FileStatus;
        }



        void Events_StoreFileRequestStarted(IFileHandler sender, Contracts.Eventing.IStoreFileRequestEventArgs e)
        {
            //e.Context.Configuration.Images.ForceImageType = "image/png";
            //if (e.Param.FileStatusItem.MainContentType == "image")
            //    e.Param.FileStatusItem.ContentType = "image/png";
            //var storageInfo = e.Param.FileStatusItem.StorageInfo;
        }


        void Events_StoreFileRequestFinished(IFileHandler sender, Contracts.Eventing.IStoreFileRequestEventArgs e)
        {
            var file = e.Param.FileStatusItem;

            if (file.StorageInfo.ChunkInfo.ChunksComplete)
            {
                // Do something
            }
        }

    }
}
