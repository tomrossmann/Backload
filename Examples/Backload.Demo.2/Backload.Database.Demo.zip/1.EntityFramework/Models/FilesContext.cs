using Backload.Contracts.Context.Provider;
using Backload.Contracts.Services.Database;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Threading.Tasks;

namespace Backload.Demo.Models
{

    /// <summary>
    /// Database context, implemets IBackloadStorageProvider
    /// </summary>
    public class FilesContext : DbContext, IBackloadStorageProvider
    {

        public DbSet<File> Files { get; set; }



        #region IBackloadStorageProvider implementation


        /// <summary>
        /// Returns a list of entities
        /// </summary>
        /// <param name="args">Provides command parameters</param>
        /// <returns>A list of IBackloadStorageProviderFile instances (stored files)</returns>
        public IEnumerable<IBackloadStorageProviderFile> Get(ICommandArgument args)
        {
            return this.Files;
        }



        /// <summary>
        /// Adds or updates an  entity (file)
        /// </summary>
        /// <param name="args">Provides command parameters</param>
        /// <returns>An IBackloadStorageProviderFile instance</returns>
        public IBackloadStorageProviderFile Add(ICommandArgument args)
        {
            var f = this.Files.Add(new File(args.FileContext));
            if (args.SaveChanges) this.SaveChanges();

            return f;
        }



        /// <summary>
        /// Updates a file entity or adds a new one if no file with the file id exists
        /// </summary>
        /// <param name="args">Provides command parameters</param>
        /// <returns>An IBackloadStorageProviderFile instance</returns>
        public IBackloadStorageProviderFile Update(ICommandArgument args)
        {
            File f = this.Files.Find(args.FileId);
            
            // Update or add file to context
            if (f != null) f.Update(args.FileContext);
            else f = this.Files.Add(new File(args.FileContext));
            if (args.SaveChanges) this.SaveChanges();

            return f;
        }



        /// <summary>
        /// Removes an entity from the database context
        /// </summary>
        /// <param name="args">Provides command parameters</param>
        /// <returns>IBackloadStorageProviderFile instance</returns>
        public IBackloadStorageProviderFile Remove(ICommandArgument args)
        {
            var file = this.Files.Find(args.FileId);
            if (file != null)
            {
                this.Files.Remove(file);
                if (args.SaveChanges) this.SaveChanges();
            }

            return file;
        }



        /// <summary>
        /// Executes an sql SELECT command with parameters
        /// </summary>
        /// <param name="args">Provides command parameters</param>
        /// <returns>A list of return type T</returns>
        public IEnumerable<T> SqlQuery<T>(ICommandArgument args)
        {
            return this.Database.SqlQuery<T>(args.SqlCommand, args.SqlParameter);
        }



        /// <summary>
        /// Executes an sql action command (Update, Insert, Delete) with parameters
        /// </summary>
        /// <param name="args">Provides command parameters</param>
        /// <returns>Number of rows affected</returns>
        public int SqlExecute(ICommandArgument args)
        {
            return this.Database.ExecuteSqlCommand(args.SqlCommand, args.SqlParameter);
        }


        #endregion IBackloadStorageProvider implementation

    }
}
